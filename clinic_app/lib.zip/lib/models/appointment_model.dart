class AppointmentModel {
  final int? id;
  final DateTime dateRdv;
  final String statut; // ATTENTE, CONFIRME, ANNULE, TERMINE
  final int patientId; 
  final String? patientName;
  final int? medecinId; 
  final String? medecinName;
  final String? motif;
  final bool is_emergency; // <--- This handles the "Ambulance" request

  AppointmentModel({
    this.id,
    required this.dateRdv,
    required this.statut,
    required this.patientId,
    this.patientName,
    this.medecinId,
    this.medecinName,
    this.motif,
    this.is_emergency = false,
  });

  factory AppointmentModel.fromJson(Map<String, dynamic> json) {
    return AppointmentModel(
      id: json['id'] as int?,
      dateRdv: DateTime.parse(json['date_rdv'] as String),
      statut: (json['statut'] as String?) ?? 'ATTENTE',
      patientId: json['patient'] as int,
      patientName: json['patient_name'] as String?,
      medecinId: json['medecin'] as int?,
      medecinName: json['medecin_name'] as String?,
      motif: json['motif'] as String?,
      is_emergency: json['is_emergency'] as bool? ?? false,
    );
  }

  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{
      'date_rdv': dateRdv.toIso8601String(),
      'statut': statut,
      'patient': patientId,
      'motif': motif,
      'is_emergency': is_emergency,
    };
    if (medecinId != null) {
      data['medecin'] = medecinId;
    }
    return data;
  }
}
