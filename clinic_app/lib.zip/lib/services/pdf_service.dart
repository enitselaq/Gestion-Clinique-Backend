import 'dart:io';
import 'package:flutter/services.dart';
import 'package:path_provider/provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:path_provider/path_provider.dart';
import '../models/prescription_model.dart';
import '../models/paiement_model.dart';

class PdfService {
  static Future<String?> exportMedicalReport({
    required PrescriptionModel prescription,
    required String patientName,
    required String patientCin,
    required String doctorName,
    required String diagnostic,
    required String notes,
  }) async {
    final pdf = pw.Document();
    
    // Load Logo
    final logoData = await rootBundle.load('assets/pdf_logo_argana.png');
    final logoImage = pw.MemoryImage(logoData.buffer.asUint8List());

    pdf.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.a4,
        build: (context) {
          return pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              // Header with Logo
              pw.Row(
                mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                children: [
                  pw.Image(logoImage, width: 80),
                  pw.Column(
                    crossAxisAlignment: pw.CrossAxisAlignment.end,
                    children: [
                      pw.Text('ARGANA CLINIQUE', style: pw.TextStyle(fontSize: 22, fontWeight: pw.FontWeight.bold, color: PdfColors.teal900)),
                      pw.Text('Service de Diagnostic Médical', style: pw.TextStyle(fontSize: 12, color: PdfColors.grey700)),
                      pw.Text('Date: ${DateTime.now().toString().substring(0, 10)}', style: pw.TextStyle(fontSize: 10)),
                    ],
                  ),
                ],
              ),
              pw.SizedBox(height: 20),
              pw.Divider(thickness: 2, color: PdfColors.teal),
              pw.SizedBox(height: 20),

              // Patient & Doctor Info
              pw.Row(
                children: [
                  pw.Expanded(
                    child: pw.Column(
                      crossAxisAlignment: pw.CrossAxisAlignment.start,
                      children: [
                        pw.Text('PATIENT:', style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 10, color: PdfColors.grey)),
                        pw.Text(patientName, style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold)),
                        pw.Text('CIN: $patientCin'),
                      ],
                    ),
                  ),
                  pw.Expanded(
                    child: pw.Column(
                      crossAxisAlignment: pw.CrossAxisAlignment.start,
                      children: [
                        pw.Text('MÉDECIN TRAITANT:', style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 10, color: PdfColors.grey)),
                        pw.Text('Dr. $doctorName', style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold)),
                      ],
                    ),
                  ),
                ],
              ),
              
              pw.SizedBox(height: 30),
              pw.Text('BILAN DE DIAGNOSTIC', style: pw.TextStyle(fontSize: 18, fontWeight: pw.FontWeight.bold, color: PdfColors.teal)),
              pw.SizedBox(height: 10),
              pw.Container(
                padding: const pw.EdgeInsets.all(10),
                decoration: pw.BoxDecoration(border: pw.Border.all(color: PdfColors.grey300), borderRadius: const pw.BorderRadius.all(pw.Radius.circular(8))),
                child: pw.Column(
                  crossAxisAlignment: pw.CrossAxisAlignment.start,
                  children: [
                    pw.Text('Diagnostic:', style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
                    pw.Text(diagnostic),
                    pw.SizedBox(height: 10),
                    pw.Text('Notes médicales:', style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
                    pw.Text(notes.isEmpty ? 'Aucune note supplémentaire.' : notes),
                  ],
                ),
              ),

              pw.SizedBox(height: 30),
              pw.Text('ORDONNANCE / PRESCRIPTION', style: pw.TextStyle(fontSize: 18, fontWeight: pw.FontWeight.bold, color: PdfColors.teal)),
              pw.SizedBox(height: 10),
              
              // Prescription Table
              pw.Table(
                border: pw.TableBorder.all(color: PdfColors.grey300),
                children: [
                  pw.TableRow(
                    decoration: const pw.BoxDecoration(color: PdfColors.teal100),
                    children: [
                      pw.Padding(padding: const pw.EdgeInsets.all(5), child: pw.Text('Médicament', style: pw.TextStyle(fontWeight: pw.FontWeight.bold))),
                      pw.Padding(padding: const pw.EdgeInsets.all(5), child: pw.Text('Dosage', style: pw.TextStyle(fontWeight: pw.FontWeight.bold))),
                      pw.Padding(padding: const pw.EdgeInsets.all(5), child: pw.Text('Instructions', style: pw.TextStyle(fontWeight: pw.FontWeight.bold))),
                    ],
                  ),
                  ...prescription.medicaments.map((m) => pw.TableRow(
                    children: [
                      pw.Padding(padding: const pw.EdgeInsets.all(5), child: pw.Text(m.nomGenerique)),
                      pw.Padding(padding: const pw.EdgeInsets.all(5), child: pw.Text(m.dosage)),
                      pw.Padding(padding: const pw.EdgeInsets.all(5), child: pw.Text(m.instructions)),
                    ],
                  )),
                ],
              ),

              pw.Spacer(),
              pw.Divider(color: PdfColors.grey300),
              pw.Center(child: pw.Text('Signature & Cachet de la Clinique', style: pw.TextStyle(fontSize: 10, color: PdfColors.grey600))),
            ],
          );
        },
      ),
    );

    final dir = await getApplicationDocumentsDirectory();
    final file = File('${dir.path}/rapport_medical_${prescription.id}.pdf');
    await file.writeAsBytes(await pdf.save());
    return file.path;
  }

  static Future<String?> exportReceipt({required PaiementModel payment, required String patientName}) async {
     // Simplified receipt logic for now
     return null;
  }
}
