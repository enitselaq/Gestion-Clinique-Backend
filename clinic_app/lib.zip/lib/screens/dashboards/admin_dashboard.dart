import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/app_theme.dart';
import '../../providers/auth_provider.dart';
import '../../services/user_service.dart';
import '../../widgets/password_dialogs.dart';

class AdminDashboard extends StatefulWidget {
  const AdminDashboard({super.key});

  @override
  State<AdminDashboard> createState() => _AdminDashboardState();
}

class _AdminDashboardState extends State<AdminDashboard> {
  final UserService _userService = UserService();
  bool _isLoading = true;
  int _patientCount = 0;
  int _doctorCount = 0;

  @override
  void initState() {
    super.initState();
    _fetchStats();
  }

  Future<void> _fetchStats() async {
    setState(() => _isLoading = true);
    try {
      final patients = await _userService.getPatients();
      final doctors = await _userService.getMedecins();
      if (!mounted) return;
      setState(() {
        _patientCount = patients.length;
        _doctorCount = doctors.length;
        _isLoading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC),
      appBar: AppBar(
        title: const Text('Administration'),
        actions: [
          IconButton(onPressed: _fetchStats, icon: const Icon(Icons.refresh_rounded)),
          IconButton(
            onPressed: () => Provider.of<AuthProvider>(context, listen: false).logout(),
            icon: const Icon(Icons.logout_rounded, color: Colors.redAccent),
          ),
        ],
      ),
      body: _isLoading 
        ? const Center(child: CircularProgressIndicator(strokeWidth: 2))
        : SingleChildScrollView(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Vue d\'ensemble', style: Theme.of(context).textTheme.headlineMedium),
                const SizedBox(height: 24),
                
                // Stats Grid
                Row(
                  children: [
                    Expanded(child: _buildStatCard('Patients', _patientCount.toString(), Icons.people_outline, Colors.blue)),
                    const SizedBox(width: 16),
                    Expanded(child: _buildStatCard('Médecins', _doctorCount.toString(), Icons.medical_services_outlined, AppTheme.primaryTeal)),
                  ],
                ),
                const SizedBox(height: 32),
                
                Text('Actions Rapides', style: Theme.of(context).textTheme.titleLarge),
                const SizedBox(height: 16),
                
                _buildActionTile('Gérer les Utilisateurs', 'Ajouter ou modifier le personnel', Icons.manage_accounts_outlined),
                _buildActionTile('Rapports d\'Activité', 'Voir les statistiques de la clinique', Icons.analytics_outlined),
                _buildActionTile('Paramètres Système', 'Configuration globale de l\'application', Icons.settings_outlined),
              ],
            ),
          ),
    );
  }

  Widget _buildStatCard(String title, String value, IconData icon, Color color) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(10)),
              child: Icon(icon, color: color, size: 24),
            ),
            const SizedBox(height: 16),
            Text(value, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
            Text(title, style: TextStyle(color: AppTheme.mutedSlate, fontWeight: FontWeight.w600)),
          ],
        ),
      ),
    );
  }

  Widget _buildActionTile(String title, String subtitle, IconData icon) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: ListTile(
        leading: Icon(icon, color: AppTheme.primaryTeal),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(subtitle),
        trailing: const Icon(Icons.chevron_right_rounded),
        onTap: () {
          // Navigate to management screens
        },
      ),
    );
  }
}
