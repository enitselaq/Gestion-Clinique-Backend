import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/app_theme.dart';
import '../../models/appointment_model.dart';
import '../../models/consultation_model.dart';
import '../../models/paiement_model.dart';
import '../../models/prescription_model.dart';
import '../../providers/auth_provider.dart';
import '../../providers/locale_provider.dart';
import '../../services/appointment_service.dart';
import '../../services/consultation_service.dart';
import '../../services/payment_service.dart';
import '../../services/prescription_service.dart';

class PatientDashboard extends StatefulWidget {
  const PatientDashboard({super.key});

  @override
  State<PatientDashboard> createState() => _PatientDashboardState();
}

class _PatientDashboardState extends State<PatientDashboard> {
  final AppointmentService _appointmentService = AppointmentService();
  final ConsultationService _consultationService = ConsultationService();
  final PrescriptionService _prescriptionService = PrescriptionService();
  final PaymentService _paymentService = PaymentService();

  List<AppointmentModel> _appointments = [];
  List<ConsultationModel> _consultations = [];
  List<PrescriptionModel> _prescriptions = [];
  List<PaiementModel> _payments = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchData();
  }

  Future<void> _fetchData() async {
    final authProvider = Provider.of<AuthProvider>(context, listen: false);
    final patientId = authProvider.user?.profileId;
    setState(() => _isLoading = true);
    try {
      final results = await Future.wait([
        _appointmentService.getAppointments(),
        _consultationService.getConsultations(),
        _prescriptionService.getPrescriptions(),
        _paymentService.getPayments(),
      ]);
      if (!mounted) return;
      setState(() {
        final appts = results[0] as List<AppointmentModel>;
        _appointments = patientId != null ? appts.where((a) => a.patientId == patientId).toList() : appts;
        _consultations = (results[1] as List<ConsultationModel>).where((c) => _appointments.any((a) => a.id == c.rdvId)).toList();
        _prescriptions = (results[2] as List<PrescriptionModel>).where((o) => _consultations.any((c) => c.id == o.consultationId)).toList();
        _payments = (results[3] as List<PaiementModel>).where((p) => _appointments.any((a) => a.id == p.rdvId)).toList();
        _isLoading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _isLoading = false);
    }
  }

  Future<void> _showDiagnosticRequestDialog() async {
    final authProvider = Provider.of<AuthProvider>(context, listen: false);
    final motifController = TextEditingController();
    bool needsAmbulance = false;
    DateTime selectedDate = DateTime.now().add(const Duration(days: 1));

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: const Text('Demande de Diagnostic'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text(
                  'Décrivez vos symptômes. Notre équipe vous contactera pour confirmer le rendez-vous.',
                  style: TextStyle(fontSize: 13, color: Colors.grey),
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: motifController,
                  maxLines: 3,
                  decoration: const InputDecoration(labelText: 'Symptômes / Motif'),
                ),
                const SizedBox(height: 16),
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  title: Text('Date: ${selectedDate.day}/${selectedDate.month}/${selectedDate.year}'),
                  leading: const Icon(Icons.calendar_today, color: AppTheme.primaryTeal),
                  onTap: () async {
                    final date = await showDatePicker(context: context, initialDate: selectedDate, firstDate: DateTime.now(), lastDate: DateTime.now().add(const Duration(days: 30)));
                    if (date != null) setDialogState(() => selectedDate = date);
                  },
                ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('Besoin d\'ambulance ?'),
                  value: needsAmbulance,
                  activeColor: Colors.redAccent,
                  onChanged: (val) => setDialogState(() => needsAmbulance = val),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('Annuler')),
            ElevatedButton(
              onPressed: () async {
                if (motifController.text.isEmpty) return;
                await _appointmentService.createAppointment(AppointmentModel(
                  dateRdv: selectedDate, statut: 'ATTENTE', patientId: authProvider.user!.profileId!, motif: motifController.text, is_emergency: needsAmbulance,
                ));
                if (!context.mounted) return;
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(needsAmbulance ? '🚨 Ambulance demandée' : '✅ Demande envoyée'), backgroundColor: needsAmbulance ? Colors.red : Colors.green));
                _fetchData();
              },
              child: const Text('Confirmer'),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final localeProvider = Provider.of<LocaleProvider>(context);

    return DefaultTabController(
      length: 5,
      child: Scaffold(
        backgroundColor: const Color(0xFFF8FAFC),
        appBar: AppBar(
          title: const Text('Espace Santé'),
          actions: [
            _buildLanguageSmallToggle(localeProvider),
            const SizedBox(width: 8),
            IconButton(onPressed: _fetchData, icon: const Icon(Icons.refresh_rounded)),
            IconButton(onPressed: () => Provider.of<AuthProvider>(context, listen: false).logout(), icon: const Icon(Icons.logout_rounded, color: Colors.redAccent)),
          ],
          bottom: const TabBar(
            isScrollable: true,
            tabAlignment: TabAlignment.start,
            tabs: [Tab(text: 'RDV'), Tab(text: 'Consultations'), Tab(text: 'Ordonnances'), Tab(text: 'À Payer'), Tab(text: 'Historique')],
          ),
        ),
        body: _isLoading
            ? const Center(child: CircularProgressIndicator(strokeWidth: 2))
            : TabBarView(
                children: [
                  _buildList(_appointments, (a) => a.is_emergency ? Icons.emergency : Icons.calendar_today_outlined, (a) => a.is_emergency ? '🚑 URGENCE' : 'Diagnostic', (a) => '${a.dateRdv.toString().substring(0, 10)} - ${a.statut}'),
                  _buildList(_consultations, (c) => Icons.medical_services_outlined, (c) => c.diagnostic, (c) => c.notes ?? ""),
                  _buildList(_prescriptions, (p) => Icons.medication_outlined, (p) => 'Ordonnance #${p.id}', (p) => 'Le ${p.dateCreation?.toString().substring(0, 10)}', trailing: Icons.download_rounded),
                  _buildPendingPayments(),
                  _buildList(_payments, (pay) => Icons.receipt_long_outlined, (pay) => '${pay.montant} MAD', (pay) => 'Payé le ${pay.datePaiement?.toString().substring(0, 10)}'),
                ],
              ),
        floatingActionButton: FloatingActionButton.extended(
          onPressed: _showDiagnosticRequestDialog,
          label: const Text('Nouveau Diagnostic'),
          icon: const Icon(Icons.add_rounded),
          backgroundColor: AppTheme.primaryTeal,
        ),
      ),
    );
  }

  Widget _buildLanguageSmallToggle(LocaleProvider provider) {
    return Row(
      children: [
        _langBtn('FR', const Locale('fr'), provider),
        _langBtn('AR', const Locale('ar'), provider),
      ],
    );
  }

  Widget _langBtn(String label, Locale loc, LocaleProvider provider) {
    final isSel = provider.locale.languageCode == loc.languageCode;
    return GestureDetector(
      onTap: () => provider.setLocale(loc),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
        margin: const EdgeInsets.symmetric(horizontal: 2),
        decoration: BoxDecoration(
          color: isSel ? AppTheme.primaryTeal.withOpacity(0.1) : Colors.transparent,
          borderRadius: BorderRadius.circular(4),
        ),
        child: Text(label, style: TextStyle(fontSize: 12, fontWeight: isSel ? FontWeight.bold : FontWeight.normal, color: isSel ? AppTheme.primaryTeal : AppTheme.mutedSlate)),
      ),
    );
  }

  Widget _buildList(List<dynamic> items, IconData Function(dynamic) icon, String Function(dynamic) title, String Function(dynamic) subtitle, {IconData? trailing}) {
    if (items.isEmpty) return const Center(child: Text('Aucune donnée', style: TextStyle(color: AppTheme.mutedSlate)));
    return ListView.builder(
      padding: const EdgeInsets.only(top: 12, bottom: 80),
      itemCount: items.length,
      itemBuilder: (context, index) {
        final item = items[index];
        bool isEm = item is AppointmentModel && item.is_emergency;
        return Card(
          child: ListTile(
            leading: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(color: (isEm ? Colors.red : AppTheme.primaryTeal).withOpacity(0.1), borderRadius: BorderRadius.circular(10)),
              child: Icon(icon(item), color: isEm ? Colors.red : AppTheme.primaryTeal),
            ),
            title: Text(title(item), style: TextStyle(fontWeight: isEm ? FontWeight.bold : FontWeight.normal, color: isEm ? Colors.red : null)),
            subtitle: Text(subtitle(item)),
            trailing: trailing != null ? Icon(trailing, color: AppTheme.mutedSlate) : null,
          ),
        );
      },
    );
  }

  Widget _buildPendingPayments() {
    final pending = _appointments.where((a) => a.statut == 'TERMINE' && !_payments.any((p) => p.rdvId == a.id)).toList();
    if (pending.isEmpty) return const Center(child: Text('Aucun paiement en attente', style: TextStyle(color: AppTheme.mutedSlate)));
    return _buildList(pending, (a) => Icons.payment_outlined, (a) => 'Dr. ${a.medecinName}', (a) => 'Consultation terminée - 200 MAD');
  }
}
