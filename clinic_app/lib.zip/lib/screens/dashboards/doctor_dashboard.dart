import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/app_theme.dart';
import '../../models/appointment_model.dart';
import '../../models/consultation_model.dart';
import '../../models/prescription_model.dart';
import '../../providers/auth_provider.dart';
import '../../services/appointment_service.dart';
import '../../services/consultation_service.dart';
import '../../services/prescription_service.dart';

class DoctorDashboard extends StatefulWidget {
  const DoctorDashboard({super.key});

  @override
  State<DoctorDashboard> createState() => _DoctorDashboardState();
}

class _DoctorDashboardState extends State<DoctorDashboard> {
  final AppointmentService _appointmentService = AppointmentService();
  final ConsultationService _consultationService = ConsultationService();
  final PrescriptionService _prescriptionService = PrescriptionService();

  List<AppointmentModel> _appointments = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchData();
  }

  Future<void> _fetchData() async {
    final doctorId = Provider.of<AuthProvider>(context, listen: false).user?.userId;
    setState(() => _isLoading = true);
    try {
      final appts = await _appointmentService.getAppointments();
      if (!mounted) return;
      setState(() {
        _appointments = appts.where((a) => a.medecinId == doctorId && a.statut == 'CONFIRME').toList();
        _isLoading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC),
      appBar: AppBar(
        title: const Text('Espace Médecin'),
        actions: [
          IconButton(onPressed: _fetchData, icon: const Icon(Icons.refresh_rounded)),
          IconButton(
            onPressed: () => Provider.of<AuthProvider>(context, listen: false).logout(),
            icon: const Icon(Icons.logout_rounded, color: Colors.redAccent),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Mes Patients du Jour', style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontSize: 24)),
            const SizedBox(height: 8),
            Text('Liste des diagnostics confirmés en attente de consultation.', 
                 style: TextStyle(color: AppTheme.mutedSlate)),
            const SizedBox(height: 24),
            Expanded(
              child: _isLoading 
                ? const Center(child: CircularProgressIndicator(strokeWidth: 2))
                : _appointments.isEmpty 
                  ? _buildEmptyState()
                  : ListView.builder(
                      itemCount: _appointments.length,
                      itemBuilder: (context, index) => _buildPatientCard(_appointments[index]),
                    ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPatientCard(AppointmentModel appt) {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  backgroundColor: AppTheme.primaryTeal.withOpacity(0.1),
                  child: const Icon(Icons.person, color: AppTheme.primaryTeal),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(appt.patientName ?? 'Patient', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
                      Text('RDV: ${appt.dateRdv.toString().substring(11, 16)}', style: TextStyle(color: AppTheme.mutedSlate)),
                    ],
                  ),
                ),
                const Icon(Icons.arrow_forward_ios_rounded, size: 16, color: Colors.grey),
              ],
            ),
            const Divider(height: 32),
            const Text('Motif de visite:', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: AppTheme.mutedSlate)),
            const SizedBox(height: 4),
            Text(appt.motif ?? 'Non spécifié', style: const TextStyle(fontSize: 15)),
            const SizedBox(height: 20),
            ElevatedButton.icon(
              onPressed: () {
                // Logic to start consultation
              },
              icon: const Icon(Icons.edit_note_rounded),
              label: const Text('Commencer la Consultation'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.assignment_turned_in_outlined, size: 64, color: AppTheme.mutedSlate.withOpacity(0.2)),
          const SizedBox(height: 16),
          Text('Aucun patient en attente', style: TextStyle(color: AppTheme.mutedSlate, fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}
