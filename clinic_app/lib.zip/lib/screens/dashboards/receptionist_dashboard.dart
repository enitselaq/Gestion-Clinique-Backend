import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/app_theme.dart';
import '../../models/appointment_model.dart';
import '../../models/doctor_model.dart';
import '../../models/patient_model.dart';
import '../../providers/auth_provider.dart';
import '../../providers/locale_provider.dart';
import '../../services/appointment_service.dart';
import '../../services/user_service.dart';

class ReceptionistDashboard extends StatefulWidget {
  const ReceptionistDashboard({super.key});

  @override
  State<ReceptionistDashboard> createState() => _ReceptionistDashboardState();
}

class _ReceptionistDashboardState extends State<ReceptionistDashboard> {
  final AppointmentService _appointmentService = AppointmentService();
  final UserService _userService = UserService();

  List<AppointmentModel> _appointments = [];
  List<PatientModel> _patients = [];
  List<DoctorModel> _doctors = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchData();
  }

  Future<void> _fetchData() async {
    setState(() => _isLoading = true);
    try {
      final results = await Future.wait([
        _appointmentService.getAppointments(),
        _userService.getPatients(),
        _userService.getMedecins(),
      ]);
      if (!mounted) return;
      setState(() {
        _appointments = results[0] as List<AppointmentModel>;
        _patients = results[1] as List<PatientModel>;
        _doctors = results[2] as List<DoctorModel>;
        _isLoading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _isLoading = false);
    }
  }

  Future<void> _showConfirmationDialog(AppointmentModel appt) async {
    DoctorModel? selectedDoctor;
    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: const Text('Confirmer le Diagnostic'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('Assigner un médecin pour ce patient.'),
              const SizedBox(height: 20),
              DropdownButtonFormField<DoctorModel>(
                decoration: const InputDecoration(labelText: 'Médecin Traitant'),
                items: _doctors.map((d) => DropdownMenuItem(value: d, child: Text('Dr. ${d.name}'))).toList(),
                onChanged: (val) => setDialogState(() => selectedDoctor = val),
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('Annuler')),
            ElevatedButton(
              onPressed: selectedDoctor == null ? null : () async {
                await _appointmentService.updateAppointment(appt.id!, {'statut': 'CONFIRME', 'medecin': selectedDoctor!.userId});
                if (!context.mounted) return;
                Navigator.pop(context);
                _fetchData();
              },
              child: const Text('Confirmer'),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final localeProvider = Provider.of<LocaleProvider>(context);

    return DefaultTabController(
      length: 2,
      child: Scaffold(
        backgroundColor: const Color(0xFFF8FAFC),
        appBar: AppBar(
          title: const Text('Réception'),
          actions: [
            _buildLanguageSmallToggle(localeProvider),
            IconButton(onPressed: _fetchData, icon: const Icon(Icons.refresh_rounded)),
            IconButton(onPressed: () => Provider.of<AuthProvider>(context, listen: false).logout(), icon: const Icon(Icons.logout_rounded, color: Colors.redAccent)),
          ],
          bottom: const TabBar(
            indicatorColor: AppTheme.primaryTeal,
            labelColor: AppTheme.primaryTeal,
            tabs: [Tab(text: 'Demandes'), Tab(text: 'Patients')],
          ),
        ),
        body: _isLoading ? const Center(child: CircularProgressIndicator(strokeWidth: 2)) : TabBarView(children: [_buildAppointmentsList(), _buildPatientsList()]),
      ),
    );
  }

  Widget _buildLanguageSmallToggle(LocaleProvider provider) {
    return Row(
      children: [
        _langBtn('FR', const Locale('fr'), provider),
        _langBtn('AR', const Locale('ar'), provider),
      ],
    );
  }

  Widget _langBtn(String label, Locale loc, LocaleProvider provider) {
    final isSel = provider.locale.languageCode == loc.languageCode;
    return GestureDetector(
      onTap: () => provider.setLocale(loc),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
        margin: const EdgeInsets.symmetric(horizontal: 2),
        decoration: BoxDecoration(color: isSel ? AppTheme.primaryTeal.withOpacity(0.1) : Colors.transparent, borderRadius: BorderRadius.circular(4)),
        child: Text(label, style: TextStyle(fontSize: 12, fontWeight: isSel ? FontWeight.bold : FontWeight.normal, color: isSel ? AppTheme.primaryTeal : AppTheme.mutedSlate)),
      ),
    );
  }

  Widget _buildAppointmentsList() {
    if (_appointments.isEmpty) return const Center(child: Text('Aucune demande'));
    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: _appointments.length,
      itemBuilder: (context, index) {
        final appt = _appointments[index];
        final isEm = appt.is_emergency;
        return Card(
          child: ExpansionTile(
            leading: CircleAvatar(backgroundColor: (isEm ? Colors.red : AppTheme.primaryTeal).withOpacity(0.1), child: Icon(isEm ? Icons.emergency : Icons.person_search_outlined, color: isEm ? Colors.red : AppTheme.primaryTeal)),
            title: Text(appt.patientName ?? 'Patient', style: TextStyle(fontWeight: FontWeight.bold, color: isEm ? Colors.red : null)),
            subtitle: Text('${appt.dateRdv.toString().substring(0, 10)} - ${appt.statut}'),
            children: [
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (isEm) const Text('🚑 AMBULANCE DEMANDÉE', style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold)),
                    const Text('Symptômes:', style: TextStyle(fontWeight: FontWeight.bold)),
                    Text(appt.motif ?? 'Non spécifié'),
                    const SizedBox(height: 16),
                    if (appt.statut == 'ATTENTE') ElevatedButton(onPressed: () => _showConfirmationDialog(appt), child: const Text('Confirmer & Assigner')),
                  ],
                ),
              )
            ],
          ),
        );
      },
    );
  }

  Widget _buildPatientsList() {
    return ListView.builder(padding: const EdgeInsets.all(12), itemCount: _patients.length, itemBuilder: (context, index) => Card(child: ListTile(title: Text(_patients[index].fullName), subtitle: Text('CIN: ${_patients[index].cin}'))));
  }
}
